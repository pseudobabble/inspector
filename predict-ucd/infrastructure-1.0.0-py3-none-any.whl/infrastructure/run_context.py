


class RunContext(dict):
    """
    An object to store transient but run-related things.
    """
